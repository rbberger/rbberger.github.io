#include <stdio.h>

#include <math.h>
#include <gmp.h>
#include <mpfr.h>

int main (void)
{
  unsigned int i;
  mpfr_t x, e, r, p;
  double r_double = exp(100);

  // calculate previous floating-point number
  double prev = nextafter(r_double, 1.0);

  mpfr_init2 (e, 200);
  mpfr_init2 (x, 200);
  mpfr_init2 (r, 200);
  mpfr_init2 (p, 200);
  mpfr_set_d (e, 100.0, GMP_RNDD);
  mpfr_set_d (r, r_double, GMP_RNDD);
  mpfr_set_d (p, prev, GMP_RNDD);

  printf ("exp(100) = %0.17g\n", r_double);
  printf("-----------------------------------------------------------------------------\n");

  // store double-precision value in 200bit float and print it
  printf ("exp(100) = ");
  mpfr_out_str (stdout, 10, 0, r, GMP_RNDD);
  putchar ('\n');
  printf ("exp(100)n= ");
  mpfr_out_str (stdout, 10, 0, p, GMP_RNDD);
  putchar ('\n');

  // calculate exp(100) using MPFR function
  mpfr_exp(x, e, GMP_RNDD);

  // print 200bit float value of exp(100)
  printf ("exp(100) = ");
  mpfr_out_str (stdout, 10, 0, x, GMP_RNDD);
  putchar ('\n');

  printf("-----------------------------------------------------------------------------\n");

  mpfr_sub(e, r, x, GMP_RNDD);
  printf ("error    = ");
  mpfr_out_str (stdout, 10, 0, e, GMP_RNDD);
  putchar ('\n');

  mpfr_clear (e);
  mpfr_clear (x);
  mpfr_clear (r);
  mpfr_clear (p);
  return 0;
}
