#include <stdio.h>

#include <math.h>

// requires GCC >= 4.6
#include <quadmath.h>

int main (void)
{
  float  x_32bit = expf(100);
  double x_64bit = exp(100);
  long double x_80bit = expl(100);

  // GNU extensions
  // support for i386, x86_64, IA-64, and hppa HP-UX, as well as on
  // PowerPC GNU/Linux targets that enable the vector scalar (VSX)
  // instruction set
  __float80 x_f80 = expl(100);
  __float128 x_f128 = expq(100);

  printf("exp(100) in 200bit precision\n"
         "2.6881171418161354484126255515800135873611118773741922415191601e43\n\n");

  printf ("float (binary32, 32bit) exp(100)\n%0.8g\n\n", x_32bit);
  printf ("double (binary64, 64bit) exp(100)\n%0.17g\n\n", x_64bit);
  printf ("long double (extended format, 80bit) exp(100)\n%0.19Le\n\n", x_80bit);

  printf ("_float80 (extended format on GNU compiler, 80bit) exp(100)\n%0.19Le\n\n", x_f80);

  char buf[50];
  quadmath_snprintf(buf, 50, "%0.34Qg", x_f128);

  printf ("_float128 (binary128 on GNU compiler, 128bit) exp(100)\n%s\n\n", buf);

  return 0;
}
