#include <stdlib.h>
#include <stdio.h>

/*
 * Average the data in i direction.
 */
void xaver(float * a, int N, float oneoverthree) {
    for(int i = 0; i < N-2; ++i) {
        a[i] = (a[i] + a[i+1] + a[i+2]) * oneoverthree;
    }
}

int main() {
    const int N = 100000;
    float a[N];
    float oneoverthree = 1.0f / 3.0f;

    // initialize the array
    for(int i = 0; i < N; ++i) {
        a[i] = float(i);
    }

    // average the array
    for(int i = 0; i < 10000; ++i) {
        xaver(a, N, oneoverthree);
    }

    printf("%22.14f %22.14f %22.14f\n", a[10000], 20000.0f, a[10000] - 20000.0f);
    return 0;
}
