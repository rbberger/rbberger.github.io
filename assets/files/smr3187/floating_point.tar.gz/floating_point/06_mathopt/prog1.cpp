#include <stdlib.h>
#include <stdio.h>

/*
 * Average the data in i direction.
 */
void xaver(float * a, int N) {
    for(int i = 0; i < N-1; ++i) {
        a[i] = (a[i] + a[i+1]) / 2.0f;
    }
}

int main() {
    const int N = 100000;
    float a[N];

    // initialize the array
    for(int i = 0; i < N; ++i) {
        a[i] = float(i);
    }

    // average the array
    for(int i = 0; i < 10000; ++i) {
        xaver(a, N);
    }

    printf("%22.14f %22.14f %22.14f\n", a[10000], 15000.0f, a[10000] - 15000.0f);
    return 0;
}
