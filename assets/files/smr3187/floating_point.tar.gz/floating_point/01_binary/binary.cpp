#include <cstdio>

using namespace std;

union ufloat {
    float f;
    unsigned int u;
};

union udouble {
    double d;
    unsigned long u;
};

void float_print_binary_repr(float f) {
    unsigned int mask = 0x1 << 31;
    ufloat uf;
    uf.f = f;
    int nbits = sizeof(f) * 8;

    for(int i = 0; i < nbits; ++i) {
        if(i == 1 || i == 9)
            printf(" ");

        if (uf.u & mask) {
            printf("1");
        } else {
            printf("0");
        }
        mask >>= 1;
    }
}

void double_print_binary_repr(double d) {
    unsigned long mask = 0x1ul << 63;
    udouble ud;
    ud.d = d;
    int nbits = sizeof(d) * 8;

    for(int i = 0; i < nbits; ++i) {
        if(i == 1 || i == 12)
            printf(" ");

        if (ud.u & mask) {
            printf("1");
        } else {
            printf("0");
        }
        mask >>= 1;
    }
}

int main() {

    // 1. use float_print_binary_repr() and double_print_binary_repr() to
    // print various binary representations of numbers between -2.0 and 2.0

    // TODO

    // 2. notice the difference it makes when you use single-precision floating-point literals vs. double-precision literals:
    // example:
    // - double-precision: 0.3
    // - single-precision: 0.3f

    double d1 = 0.3;
    double d2 = 0.3f;
    float  d3 = 0.3f;

    printf("0.3 (DP) saved in a DP float:\n");
    double_print_binary_repr(d1);
    printf(" = %lf (0.3) = %0.15lf\n\n", d1, d1);

    printf("0.3f (SP) saved in a DP float:\n");
    double_print_binary_repr(d2);
    printf(" = %f (0.3f) = %0.15lf\n\n", d2, d2);

    printf("0.3f (SP) saved in a SP float:\n");
    float_print_binary_repr(d3);
    printf(" = %f (0.3f) = %0.7f\n\n", d3, d3);

    return 0;
}
