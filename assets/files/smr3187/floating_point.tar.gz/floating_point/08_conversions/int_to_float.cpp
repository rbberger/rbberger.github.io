#include <stdio.h>

// 1. run this program and observe how very large integers are rounded when converted to floats

int main() {
    const int max_exact_int_in_float = 16777216; // -(2^24)
    const long max_exact_long_in_double = 9007199254740992; // -(2^53)

    printf("---------------------------\n");
    printf("rounding int to float\n");

    for(int offset = -2; offset < 10; offset++) {
        int i = max_exact_int_in_float + offset;
        float f = i;
        printf("f = (float)%d = %f\n", i, f);
    }

    printf("---------------------------\n");
    printf("rounding long to double\n");

    for(int offset = -2; offset < 10; offset++) {
        long i = max_exact_long_in_double + offset;
        double f = i;
        printf("f = (double)%ld = %lf\n", i, f);
    }

    return 0;
}
