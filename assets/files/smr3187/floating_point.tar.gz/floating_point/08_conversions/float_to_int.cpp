#include <stdio.h>

// 1. run this program and observe how converting a double that is out of range is transformed to a smaller type

int main() {
    // 2. observe what changes if you use int and short as data type for these constants
    //    why does this change the computation result?
    const double min_representable_int = -2147483648; // -(2^31)
    const double max_representable_int = 2147483647; // 2^31 - 1
    const double min_representable_short = -32768; // -(2^15)
    const double max_representable_short = 32767; // 2^15-1

    printf("---------------------------\n");
    printf("overflow double -> int\n");

    for(int offset = 0; offset < 10; offset++) {
        double f = max_representable_int + offset;
        int i = (int)f;
        printf("i = (int)%f = %d\n", f, i);
    }

    printf("---------------------------\n");
    printf("overflow double -> short\n");


    for(int offset = 0; offset < 10; offset++) {
        double f = max_representable_short + offset;
        short s = (short)f;
        printf("s = (short)%f = %d\n", f, s);
    }

    printf("---------------------------\n");
    printf("overflow float -> short\n");

    for(int offset = 0; offset < 10; offset++) {
        float f = max_representable_short + offset;
        short s = (short)f;
        printf("s = (short)%f = %d\n", f, s);
    }

    printf("---------------------------\n");
    printf("underflow double -> int\n");

    for(int offset = 0; offset < 10; offset++) {
        double f = min_representable_int - offset;
        int i = (int)f;
        printf("i = (int)%f = %d\n", f, i);
    }

    printf("---------------------------\n");
    printf("underflow double -> short\n");


    for(int offset = 0; offset < 10; offset++) {
        double f = min_representable_short - offset;
        short s = (short)f;
        printf("s = (short)%f = %d\n", f, s);
    }

    printf("---------------------------\n");
    printf("underflow float -> short\n");

    for(int offset = 0; offset < 10; offset++) {
        float f = min_representable_short - offset;
        short s = (short)f;
        printf("s = (short)%f = %d\n", f, s);
    }
    return 0;
}
