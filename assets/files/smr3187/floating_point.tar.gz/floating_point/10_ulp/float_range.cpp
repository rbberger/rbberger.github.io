#include <stdio.h>
#include <cmath>

using namespace std;

int float_to_ordinal(float x) {
    float f = fabs(x);
    int n = *((int*)&f);
    return (x <= 0) ? -n : n;
}

float ordinal_to_float(int n) {
    int m = (n < 0) ? -n : n;
    float x = *((float*)&m);
    return (n < 0) ? -x : x;
}

int main() {
    int fa1 = float_to_ordinal(1.0f);
    int fb2 = float_to_ordinal(2.0f);
    int fdelta1 = fb2 - fa1;
    printf("delta between 1.0 and 2.0: %d\n", fdelta1);

    int fa1023 = float_to_ordinal(1023.0f);
    int fb1024 = float_to_ordinal(1024.0f);
    int fdelta2 = fb1024 - fa1023;
    printf("delta between 1023.0 and 1024.0: %d\n", fdelta2);

    printf("--------\n");

    // prints all numbers between 1023.0 to 1024.0
    for(int i = fa1023; i <= fb1024; ++i) {
        float f = ordinal_to_float(i);
        printf("%f\n", f);
    }

    return 0;
}
