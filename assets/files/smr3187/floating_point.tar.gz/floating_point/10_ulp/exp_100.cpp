#include <stdio.h>
#include <cmath>

using namespace std;

// determines position of FP on number axis
int64_t double_to_ordinal(double x) {
    double f = fabs(x);
    int64_t n = *((int64_t*)&f);
    return (x <= 0) ? -n : n;
}

// converts a position on the number axis back to FP
double ordinal_to_double(int64_t n) {
    int64_t m = (n < 0) ? -n : n;
    double x = *((double*)&m);
    return (n < 0) ? -x : x;
}

int main() {
    double x = exp(100);

    double nextx = nextafter(x, x+1e28);

    printf("exp(100):\n");
    printf("%lf\n", x);

    printf("next float after exp(100)");
    printf("%lf\n", nextx);


    double d = nextx - x;
    printf("ULP: %g\n", d);

    printf("--------------\n");

    // alternative way of getting next floating-point number
    int64_t ox = double_to_ordinal(x);
    ox++;
    nextx = ordinal_to_double(ox);

    printf("exp(100):\n");
    printf("%lf\n", x);
    printf("next float after exp(100)");
    printf("%lf\n", nextx);
    d = nextx - x;

    printf("ULP: %g\n", d);
    printf("%g\n", d);
    return 0;
}
