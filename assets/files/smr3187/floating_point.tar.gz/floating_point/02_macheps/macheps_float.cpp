// a simple program to compute macheps for the machine you are working on
#include <cstdio>

using namespace std;
 
int main() {
   float machEps = 1.0f;

   printf("current Epsilon, 1 + current Epsilon\n");
   do {
      printf( "%G\t%.9f\n", machEps, (1.0f + machEps) );
      machEps /= 2.0f;
      // If next epsilon yields 1, then break, because current
      // epsilon is the machine epsilon.
   }
   while ((float)(1.0 + (machEps/2.0)) != 1.0);

   printf( "\nCalculated Machine epsilon: %G\n", machEps );
   return 0;
}
