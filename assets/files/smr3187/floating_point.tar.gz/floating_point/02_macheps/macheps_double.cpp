// a simple program to compute macheps for the machine you are working on
 #include <cstdio>

using namespace std;
 
int main() {
   double machEps = 1.0;

   printf("current Epsilon, 1 + current Epsilon\n");
   do {
      printf( "%G\t%.17lf\n", machEps, (1.0 + machEps) );
      machEps /= 2.0;
      // If next epsilon yields 1, then break, because current
      // epsilon is the machine epsilon.
   }
   while ((1.0 + (machEps/2.0)) != 1.0);

   printf( "\nCalculated Machine epsilon: %G\n", machEps );
   return 0;
}
