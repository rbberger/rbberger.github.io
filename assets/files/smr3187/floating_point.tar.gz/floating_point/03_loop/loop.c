#include <stdio.h>
int main (int argc, char **argv) {

  int i;
  float x;

  printf("adding x += 0.01 while x < 1.0\n");

  // summation using floating-point condition
  i=0;
  for (x=0.0; x < 1.0; x += 0.01, ++i) {
      printf("x[%d]=%f\n", i, x);
  }
  // i=100 is still executed because 0.99999 is still < 1.0

  printf("===========\n");

  printf("adding x += 0.01 for 100 steps\n");

  // summation using integer condition
  x=0.0;
  for (i=0; i < 100; x += 0.01, ++i) {
      printf("x[%d]=%f\n", i, x);
  }
  return 0;
}
