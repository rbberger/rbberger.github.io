#include <cstdio>

using namespace std;

void check_for_inverse() {
    int problematic = 0;

    for(int i = 1; i <= 100; ++i) {
        float x = 1.0f / i;
        float y = x * i;

        if(y != 1.0f) {
            printf("inverse of %d is not correct: %0.9f\n", i, y);
            problematic++;
        }
    }
    printf("found %d problematic inverses\n", problematic);
}

int main() {
    check_for_inverse();
    return 0;
}
