#include <fenv.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <float.h>

int main() {

    // Uncomment the following line to enable FP traps
    // feenableexcept(FE_INVALID | FE_DIVBYZERO | FE_UNDERFLOW | FE_OVERFLOW);
    
    // this will send SIGFPE if one of the select FP exceptions happens
    // by default, these are silently reported
    // by enabling you will crash your program
    // this is useful to determine the source of NaNs or divisions by zero

    // you can debug the core dump using gdb
    // $ gdb -c core.49841 exceptions
    // $ (gdb) bt
    // $ (gdb) list

    // but you can also check for FE conditions at runtime

    // clear all FP exceptions
    feclearexcept(FE_ALL_EXCEPT);

    printf("invalid operation\n");
    printf("0.0 / 0.0  = %lf\n", 0.0 / 0.0);
    printf("inf / inf  = %lf\n", INFINITY / INFINITY);
    if(fetestexcept(FE_INVALID)) {
        printf("Invalid operation detected!\n");
    }

    printf("-----------------------\n");
    printf("division by zero\n");
    printf("1.0 / 0.0  = %lf\n", 1.0 / 0.0);
    printf("-1.0 / 0.0 = %lf\n", -1.0 / 0.0);
    if(fetestexcept(FE_DIVBYZERO)) {
        printf("Division by zero detected!\n");
    }

    printf("-----------------------\n");
    printf("overflow\n");
    printf("DBL_MAX+1e294 = %lf\n", DBL_MAX+1.0e294);
    printf("exp(709.8)    = %lf\n", exp(709.8));
    if(fetestexcept(FE_OVERFLOW)) {
        printf("Overflow detected!\n");
    }

    
    printf("-----------------------\n");
    printf("underflow\n");
    printf("DBL_MIN/3.0 = %lf\n", DBL_MIN/3.0);
    printf("nextafter(DBL_MIN,-INFINITY) = %lf\n", nextafter(DBL_MIN, -INFINITY));
    if(fetestexcept(FE_UNDERFLOW)) {
        printf("Underflow detected!\n");
    }

    return 0;
}
