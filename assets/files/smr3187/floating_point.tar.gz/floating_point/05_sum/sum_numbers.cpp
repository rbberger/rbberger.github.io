/*
 * This program computes the sum of the first N numbers
 * It performs the operation using Integer numbers and FP numbers 
 * and prints out the results of both Integer and FP sum
 *
 * Operations are performed in two ways:
 * 1. summing from 1 to N (from the smallest to the largest)
 * 2. summing from N to 1 (from the largest  to the smallest)
 */

// try out the following values 10, 100, 1000, 5900, 5901, 100000, 150000000
#include <stdio.h>

long sum_ascending_long(int nsteps) {
    long sum = 0.0;
    int number = 1;
    for(int i = 0; i < nsteps; ++i) {
        sum += long(number);
        number += 1;
    }
    return sum;
}

float sum_ascending_float(int nsteps) {
    float sum = 0.0;
    int number = 1;
    for(int i = 0; i < nsteps; ++i) {
        sum += float(number);
        number += 1;
    }
    return sum;
}

double sum_ascending_double(int nsteps) {
    double sum = 0.0;
    int number = 1;
    for(int i = 0; i < nsteps; ++i) {
        sum += double(number);
        number += 1;
    }
    return sum;
}

long sum_descending_long(int nsteps) {
    long sum = 0;
    int number = nsteps;
    for(int i = 0; i < nsteps; ++i) {
        sum += long(number);
        number -= 1;
    }
    return sum;
}

float sum_descending_float(int nsteps) {
    float sum = 0.0;
    int number = nsteps;
    for(int i = 0; i < nsteps; ++i) {
        sum += long(number);
        number -= 1;
    }
    return sum;
}

double sum_descending_double(int nsteps) {
    double sum = 0.0;
    int number = nsteps;
    for(int i = 0; i < nsteps; ++i) {
        sum += double(number);
        number -= 1;
    }
    return sum;
}

long gauss_formula_long(long k) {
    return (k*(k+1)) / 2;
}

float gauss_formula_float(float k) {
    return (k*(k+1)) / 2;
}

double gauss_formula_double(double k) {
    return (k*(k+1)) / 2;
}

int main() {
    int nsteps = 0;
    
    printf("Enter N: ");
    scanf("%d", &nsteps);

    long sum_asc_i = sum_ascending_long(nsteps);
    float sum_asc_f = sum_ascending_float(nsteps);
    double sum_asc_d = sum_ascending_double(nsteps);

    long sum_desc_i = sum_descending_long(nsteps);
    float sum_desc_f = sum_descending_float(nsteps);
    double sum_desc_d = sum_descending_double(nsteps);

    long gauss_i = gauss_formula_long(nsteps);
    float gauss_f = gauss_formula_float((float)nsteps);
    double gauss_d = gauss_formula_double((double)nsteps);

    printf("the mathematical correct result:\n\n");
    printf("n(n+1)\n");
    printf("------  = %ld (long), %f (float), %lf (double))\n", gauss_i, gauss_f, gauss_d);
    printf("   2\n\n");

    printf("summing integers:\n");
    printf(" - ascending:  %ld\n", sum_asc_i);
    printf(" - descending: %ld\n", sum_desc_i);
    printf("\n");
    printf("summing single precision floating-point numbers:\n");
    printf(" - ascending:  %ld (%f)\n", long(sum_asc_f), sum_asc_f);
    printf(" - descending: %ld (%f)\n", long(sum_desc_f), sum_desc_f);
    printf("\n");
    printf("summing double precision floating-point numbers:\n");
    printf(" - ascending:  %ld (%lf)\n", long(sum_asc_d), sum_asc_d);
    printf(" - descending: %ld (%lf)\n", long(sum_desc_d), sum_desc_d);
    return 0;
}
