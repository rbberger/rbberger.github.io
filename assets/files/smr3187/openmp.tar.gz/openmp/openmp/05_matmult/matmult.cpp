#include <stdio.h>
#include <stdlib.h>

void print_matrix(double * a, int N, int M) {
    if(N > 80 || M > 80) {
        printf("%d x %d matrix\n", N, M);
        return;
    }

    for(int i = 0; i < N; ++i) {
        for(int j = 0; j < M; ++j) {
            printf("%g ", a[i*M + j]);
        }
        printf("\n");
    }
}

void save_matrix(const char * filename, double * a, int N, int M) {
    FILE* f = fopen(filename, "w");
    for(int i = 0; i < N; ++i) {
        for(int j = 0; j < M; ++j) {
            fprintf(f, "%g ", a[i*M + j]);
        }
        fprintf(f, "\n");
    }
    fclose(f);
}

void fill_matrix(double * a, int M, int N, double value) {
    for(int i = 0; i < M; ++i) {
        for(int j = 0; j < N; ++j) {
            a[i*N + j] = value;
        }
    }
}

void matrix_multiply(double * a, double * b, double * c, const int M, const int N, const int K) {
    for(int i = 0; i < M; ++i) {
        for(int j = 0; j < N; ++j) {
            c[i*N + j] = 0.0;

            for(int k = 0; k < K; ++k) {
                c[i*N + j] += a[i*K + k] * b[k*N + j];
            }
        }
    }
}

int main(int argc, char ** argv) {
    if(argc < 4) {
        printf("USAGE %s M K N\n", argv[0]);
        return 1;
    }

    const int M = atoi(argv[1]);
    const int K = atoi(argv[2]);
    const int N = atoi(argv[3]);

    // MxK * KxN = MxN 

    double * a = new double[M*K];
    double * b = new double[K*N];
    double * c = new double[M*N];

    // init matrices
    fill_matrix(a, M, K, 1.0);
    fill_matrix(b, K, N, 2.0);
    fill_matrix(c, M, N, 0.0);

    // print matrix A and B

    printf("A:\n");
    print_matrix(a, M, K);

    printf("\n");
    printf("B:\n");
    print_matrix(b, K, N);

    // multiply them
    matrix_multiply(a, b, c, M, N, K);

    // print result

    printf("\n");
    printf("C:\n");
    print_matrix(c, M, N);
    save_matrix("result.txt", c, M, N);

    delete [] c;
    delete [] b;
    delete [] a;
}
