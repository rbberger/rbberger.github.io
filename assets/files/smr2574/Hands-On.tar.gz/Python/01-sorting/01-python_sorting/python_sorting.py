########################################################################
#
# Sorting in Python
# 
# Created for the ICTP Workshop on Advanced Techniques for Scientific
# Programming and Management of Open Source Software Packages
# 10. - 21. March, 2014 in Trieste, Italy
#
# Richard Berger <richard.berger@jku.at>
#
########################################################################
from __future__ import print_function
import random
import time

# set random seed so all our computations are repeatable
random.seed(1)

########################################################################
# Python sorting mechanisms

# creates a random sequence of length N
N = 10
sequence = list(range(N))
random.shuffle(sequence)

# TODO 0: create a copy of the sequence

# TODO 1: sort the copied sequence in ascending order
# using the sort method of the list object
# use print() to check the results


# TODO 2: now sort the copied sequence in descending order
# using the sort method of the list object
# use print() to check the results

print("--------------------------------------------------------------")

# create sorted copy of the sequence using the sorted() function
# What is the difference between the sort method and the sort function?

print("--------------------------------------------------------------")

