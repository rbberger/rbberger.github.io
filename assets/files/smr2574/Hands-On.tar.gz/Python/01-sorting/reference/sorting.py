########################################################################
#
# Comparison of different sorting algorithms
# 
# Created for the ICTP Workshop on Advanced Techniques for Scientific
# Programming and Management of Open Source Software Packages
# 10. - 21. March, 2014 in Trieste, Italy
#
# Richard Berger <richard.berger@jku.at>
#
########################################################################
from __future__ import print_function
import random
import time
from collections import OrderedDict

# set random seed so all our computations are repeatable
random.seed(1)

########################################################################
# Insertion Sort


def insertion_sort(seq):
    """
    in-place implementation of insertion sort algorithm
    """
    for j in range(1, len(seq)):
        key = seq[j]
        i = j - 1
        while i >= 0 and seq[i] > key:
            seq[i+1] = seq[i]
            i -= 1
        seq[i+1] = key


########################################################################
# Merge Sort


def _merge(seq, p, q, r):
    """
    merges the two sorted sequences seq[p:q] and seq[q:r] and stores
    the final result in seq[p:r]
    """
    left = seq[p:q]
    right = seq[q:r]

    left.append(None)
    right.append(None)

    i = 0
    j = 0

    for k in range(p, r):
        if left[i] is None:
            seq[k] = right[j]
            j += 1
        elif (right[j] is None) or left[i] < right[j]:
            seq[k] = left[i]
            i += 1
        else:
            seq[k] = right[j]
            j += 1


def _merge_sort(seq, p, r):
    """
    sorts a sub-sequence seq[p:r]
    """
    if p+1 < r:
        q = int((p+r) / 2)
        _merge_sort(seq, p, q)
        _merge_sort(seq, q, r)
        _merge(seq, p, q, r)


def merge_sort(seq):
    _merge_sort(seq, 0, len(seq))


########################################################################
# Quick Sort


def quick_sort(seq):
    """
    quick sort using list comprehensions
    :rtype list
    """
    if not seq:
        return []
    else:
        pivot = seq[0]
        lesser = quick_sort([x for x in seq[1:] if x < pivot])
        greater = quick_sort([x for x in seq[1:] if x >= pivot])
        return lesser + [pivot] + greater

########################################################################
# Utilities


def is_sorted(seq):
    """
    Check if sequence is sorted
    :rtype : bool
    """
    return all(seq[i] <= seq[i + 1] for i in range(len(seq) - 1))


########################################################################
# Evaluation

lengths = list(range(1000, 10000, 100)) + list(range(10000, 50000, 1000))

timings = OrderedDict()
timings['python_sort'] = []
timings['python_sorted'] = []
timings['merge_sort'] = []
timings['quick_sort'] = []
timings['insertion_sort'] = []

# create random sequences of length N and time their sorting time
# using different algorithms
for N in lengths:
    print("=========================================================")
    print("N = ", N)
    print("=========================================================")

    # generate random sequence
    sequence = list(range(N))
    random.shuffle(sequence)

    # python sorting
    a = sequence[:]
    start = time.clock()
    a.sort()
    end = time.clock()
    delta = end - start
    timings['python_sort'].append(delta)
    print("Python sort() function:", delta, " seconds")
    print("Sorted: ", is_sorted(a))

    a = sequence[:]
    start = time.clock()
    a = sorted(a)
    end = time.clock()
    delta = end - start
    timings['python_sorted'].append(delta)
    print("Python sorted() function:", delta, " seconds")
    print("Sorted: ", is_sorted(a))

    # merge sort
    a = sequence[:]
    start = time.clock()
    merge_sort(a)
    end = time.clock()
    delta = end - start
    timings['merge_sort'].append(delta)
    print("Merge Sort:", delta, " seconds")
    print("Sorted: ", is_sorted(a))

    # quick sort
    a = sequence[:]
    start = time.clock()
    a = quick_sort(a)
    end = time.clock()
    delta = end - start
    timings['quick_sort'].append(delta)
    print("Quick Sort:", delta, " seconds")
    print("Sorted: ", is_sorted(a))

    # insertion sort
    a = sequence[:]
    start = time.clock()
    insertion_sort(a)
    end = time.clock()
    delta = end - start
    timings['insertion_sort'].append(delta)
    print("Insertion Sort:", delta, " seconds")
    print("Sorted: ", is_sorted(a))

# plot execution times of different algorithms
import matplotlib.pyplot as plt

# plot 
# (Key, Value) = (Algorithm Name, List of Timings)
for k, v in timings.items():
    # lengths ... values of N
    # v       ... timings of current algorithm
    plt.plot(lengths, v)

plt.xlabel('N')
plt.ylabel('runtime in seconds')
plt.legend(timings.keys(), 2)
plt.grid()
plt.show()
