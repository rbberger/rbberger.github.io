########################################################################
#
# Sorting in Python
# 
# Created for the ICTP Workshop on Advanced Techniques for Scientific
# Programming and Management of Open Source Software Packages
# 10. - 21. March, 2014 in Trieste, Italy
#
# Richard Berger <richard.berger@jku.at>
#
########################################################################
from __future__ import print_function
import random
import time

# set random seed so all our computations are repeatable
random.seed(1)

########################################################################
# Python sorting mechanisms

# create a random sequence of length N
N = 10
sequence = list(range(N))
random.shuffle(sequence)

# sort list in place
a = sequence[:] # creates copy
print("before: a = ", a)
# ascending
a.sort()
print("after: a = ", a)

# descending
a.sort(reverse=True)
print("after: a = ", a)

print("--------------------------------------------------------------")

# create sorted copy
a = sequence[:]
print("before: a = ", a)
b = sorted(a)
print("after: a = ", a)
print("after: b = ", b)

print("--------------------------------------------------------------")

