########################################################################
#
# Comparison of access times of data structures
# 
# Created for the ICTP Workshop on Advanced Techniques for Scientific
# Programming and Management of Open Source Software Packages
# 10. - 21. March, 2014 in Trieste, Italy
#
# Richard Berger <richard.berger@jku.at>
#
########################################################################
from __future__ import print_function
import csv
import time

def load_countries(filename):
    """ 
    This methods load all countries from a CSV file
    It returns both a list and a dictionary of the data
    """
    c_list = []
    c_dict = {}

    with open(filename, 'r') as csvfile:
        reader = csv.reader(csvfile)
        fields = None
        for row in reader:
            if not fields:
                # store first row as fields
                fields = row
            else:
                i = 0
                entry = {}
                for f in fields:
                    entry[f] = row[i]
                    i += 1
                c_list.append(entry)
                c_dict[entry['ISO 3166-1 2 Letter Code']] = entry
    return c_list, c_dict

# get list and dictionary of countries
country_list, country_dict = load_countries('../../../Data/iso_3166_2_countries.csv')

# create sorted list of countries, sorted by their 2 letter ISO code
sorted_country_list = sorted(country_list, key=lambda x: x['ISO 3166-1 2 Letter Code'])

########################################################################
# Linear Search in list

def get_country_name_from_list(two_letter_code):
    for x in country_list:
        if x['ISO 3166-1 2 Letter Code'] == two_letter_code:
            return x['Common Name']
    return 'Unknown'



########################################################################
# Linear Search in list


def binary_search(two_letter_code, s, e):
    if e < s:
        return 'Unknown'
    m = int((s + e) / 2)
    country = sorted_country_list[m]
    country_code = country['ISO 3166-1 2 Letter Code']
    if country_code == two_letter_code:
        return country['Common Name']
    elif country_code < two_letter_code:
        return binary_search(two_letter_code, m+1, e)
    else:
        return binary_search(two_letter_code, s, m-1)


def get_country_name_with_binary_search(two_letter_code):
    return binary_search(two_letter_code, 0, len(country_list)-1)

########################################################################
# Linear Search in list

def get_country_name_from_dict(two_letter_code):
    if two_letter_code in country_dict:
        return country_dict[two_letter_code]['Common Name']
    return 'Unknown'


########################################################################
# Evaluation: lookup needles in data structures N times and measure the
#             performance

needles = ['AT', 'IT', 'HU', 'US']
linearTimes = []
binarySearchTimes = []
dictTimes = []
N = 100000 # number of times we will access data structure

for needle in needles:
    ####################################################################
    start = time.clock()

    for x in range(N):
        name = get_country_name_from_list(needle)

    print(name)

    end = time.clock()
    delta = end - start
    linearTimes.append(delta)
    print("Linear search:", delta, " seconds")

    ####################################################################
    start = time.clock()

    for x in range(N):
        name = get_country_name_with_binary_search(needle)

    print(name)

    end = time.clock()
    delta = end - start
    binarySearchTimes.append(delta)
    print("Binary Search:", delta, " seconds")

    ####################################################################
    start = time.clock()

    for x in range(N):
        name = get_country_name_from_dict(needle)

    print(name)

    end = time.clock()
    delta = end - start
    dictTimes.append(delta)
    print("Dictionary lookup:", delta, " seconds")


# plot lookup times of different countries
import matplotlib.pyplot as plt
import numpy as np

fig, ax = plt.subplots()

indices = np.arange(len(needles))
width = 0.25

linear = ax.bar(indices, linearTimes, width, color='r')
binary = ax.bar(indices+width, binarySearchTimes, width, color='g')
dictionary = ax.bar(indices+2*width, dictTimes, width, color='b')

ax.legend((linear[0], binary[0], dictionary[0]), 
('List: linear search', 
 'Sorted List: binary search',
 'Dictionary'))

ax.set_xticks(indices+2*width)
ax.set_xticklabels(needles)
ax.set_ylabel('Lookup times x%d in seconds' % N)
plt.xlabel('search term')
plt.show()
