########################################################################
#
# Comparison of access times of data structures
# 
# Created for the ICTP Workshop on Advanced Techniques for Scientific
# Programming and Management of Open Source Software Packages
# 10. - 21. March, 2014 in Trieste, Italy
#
# Richard Berger <richard.berger@jku.at>
#
########################################################################
from __future__ import print_function
import csv
import time

def load_countries(filename):
    """ 
    This methods load all countries from a CSV file
    It returns both a list and a dictionary of the data
    """
    c_list = []
    c_dict = {}

    with open(filename, 'r') as csvfile:
        reader = csv.reader(csvfile)
        fields = None
        for row in reader:
            if not fields:
                # store first row as fields
                fields = row
            else:
                i = 0
                entry = {}
                for f in fields:
                    entry[f] = row[i]
                    i += 1
                c_list.append(entry)
                c_dict[entry['ISO 3166-1 2 Letter Code']] = entry
    return c_list, c_dict

# get list and dictionary of countries
country_list, country_dict = load_countries('../../../Data/iso_3166_2_countries.csv')

# create sorted list of countries, sorted by their 2 letter ISO code
sorted_country_list = sorted(country_list, key=lambda x: x['ISO 3166-1 2 Letter Code'])


def get_country_name_from_list(two_letter_code):
    # TODO Implement a function which does a linear search inside the 'country_list' for 
    # the given 'two_letter_code' and return the 'Common Name' field of the country.
    #
    # Linear search means that you iterate through the list and look at each element.
    # Each country element is a dictionary. The two letter code is stored with the key 
    # 'ISO 3166-1 2 Letter Code'.
    # If no country has a matching code, return 'Unknown'
    pass


