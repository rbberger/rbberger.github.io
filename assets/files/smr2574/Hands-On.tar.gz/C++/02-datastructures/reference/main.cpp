/*
 * Comparison of accessing different data structures
 *
 * Created for the ICTP Workshop on Advanced Techniques for Scientific
 * Programming and Management of Open Source Software Packages
 * 10. - 21. March, 2014 in Trieste, Italy
 *
 * Richard Berger <richard.berger@jku.at>
*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <memory>
#include <iterator>
#include <chrono>
#include <algorithm>
#include <unordered_map>

using namespace std;

using timer = chrono::high_resolution_clock;

/**
 * Simple structure to store the common name and 2-letter ISO code of a country
 */
struct Country {
public:
  string commonName;
  string isoCode;

  Country() {
  }

  Country(const string & cn, const string & isoCode) : commonName(cn), isoCode(isoCode) {
  }
};

/*
 * Countries are sorted by their 2-letter ISO code
 */
bool operator<(const Country& a, const Country& b) {
  return a.isoCode < b.isoCode;
}

/**
 * Utility class to read a CSV file and access its data
 */
class CSVReader {
  vector<vector<string>> data;

public:
  CSVReader(ifstream & in) {
    string line;
    if (in.is_open())
    {
        while (getline(in,line))
        {
            stringstream lineStream(line);
            string cell;
            std::vector<string> row;

            while(getline(lineStream,cell,',')) {
              row.push_back(cell);
            }

            data.push_back(row);
        }
    }
  }

  const string & cell(int row, int column) {
    return data[row][column];
  }

  int columns() const {
    return data[0].size();
  }

  int rows() const {
    return data.size();
  }
};

static const string unknown("Unknown");

///////////////////////////////////////////////////////////////////////////////////
// linear search

const string & get_country_name_from_list(vector<Country> & list, const string & isoCode)
{
  for(int i = 0; i < list.size(); i++) {
    if(list[i].isoCode == isoCode) {
        return list[i].commonName;
    }
  }
  return unknown;
}

///////////////////////////////////////////////////////////////////////////////////
// binary search

const string & binary_search(const vector<Country> & list, const string & two_letter_code, int s, int e) {
    if (e < s) return unknown;
    int m = (s + e) / 2;
    auto & country = list[m];
    if (country.isoCode == two_letter_code) {
        return country.commonName;
    } else if (country.isoCode < two_letter_code) {
      return binary_search(list, two_letter_code, m+1, e);
    }
    return binary_search(list, two_letter_code, s, m-1);
}

const string & get_country_name_with_binary_search(const vector<Country> & list, const string & two_letter_code) {
  return binary_search(list, two_letter_code, 0, list.size()-1);
}

///////////////////////////////////////////////////////////////////////////////////
// access ordered map (aka. map)

const string & get_country_name_from_dict(map<string, Country> & dict, const string & isoCode) {
  return dict[isoCode].commonName;
}

///////////////////////////////////////////////////////////////////////////////////
// access unordered map (aka. hash map)

const string & get_country_name_from_hashmap(unordered_map<string, Country> & dict, const string & isoCode) {
  return dict[isoCode].commonName;
}



///////////////////////////////////////////////////////////////////////////////////

int main()
{
  vector<Country> country_list;
  map<string, Country> country_dict;
  unordered_map<string, Country> country_hashmap;

  ///////////////////////////////////////////////////////////////////////////////////
  // read in data from CSV file
  ifstream countryData;
  countryData.open("../../../Data/iso_3166_2_countries.csv");
  CSVReader reader(countryData);
  countryData.close();

  const int COMMON_NAME_IDX = 1;
  const int ISO_COUNTRY_CODE_IDX = 10;

  ///////////////////////////////////////////////////////////////////////////////////
  // build lists and dictionaries from CSV data
  for(int i = 0; i < reader.rows(); i++) {
      const string & commonName = reader.cell(i, COMMON_NAME_IDX);
      const string & isoCode = reader.cell(i, ISO_COUNTRY_CODE_IDX);

      if(commonName.length() == 0 || isoCode.length() == 0) continue;

      country_list.push_back(Country(commonName, isoCode));
      country_dict[isoCode] = Country(commonName, isoCode);
      country_hashmap[isoCode] = Country(commonName, isoCode);
  }

  vector<Country> sorted_country_list(country_list);
  sort(sorted_country_list.begin(), sorted_country_list.end());

  ///////////////////////////////////////////////////////////////////////////////////
  // Evaluation
  vector<string> needles { "AT", "IT" , "HU", "US" }; // C++11 initializer list
  vector<double> linearTimes;
  vector<double> binarySearchTimes;
  vector<double> dictTimes;
  vector<double> hashmapTimes;
  const int N = 100000;

  for(auto & needle : needles) {
      auto start = timer::now();
      string name;

      for(int i = 0; i < N; i++)
        name = get_country_name_from_list(country_list, needle);

      auto end = timer::now();
      double delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;
      linearTimes.push_back(delta);

      cout << name << endl;
      cout << "Linear search: " << delta << " seconds" << endl;

      // ---------------------------------------------------------------------

      start = timer::now();

      for (int i = 0; i < N; i++)
        name = get_country_name_with_binary_search(sorted_country_list, needle);

      end = timer::now();
      delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;
      binarySearchTimes.push_back(delta);

      cout << name << endl;
      cout << "Binary Search: " <<  delta << " seconds" << endl;

      // ---------------------------------------------------------------------

      start = timer::now();

      for (int i = 0; i < N; i++)
        name = get_country_name_from_dict(country_dict, needle);

      end = timer::now();
      delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;
      dictTimes.push_back(delta);

      cout << name << endl;
      cout << "Dictionary lookup: " << delta << " seconds" << endl;

      // ---------------------------------------------------------------------

      start = timer::now();

      for (int i = 0; i < N; i++)
        name = get_country_name_from_hashmap(country_hashmap, needle);

      end = timer::now();
      delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;
      hashmapTimes.push_back(delta);

      cout << name << endl;
      cout << "Hashmap lookup: " << delta << " seconds" << endl;

      cout << "==============================================================" << endl;
  }

  // generate output as data file for gnuplot
  ofstream output;
  output.open("output.csv");
  output << "id,key,Linear search,Binary search,Dictionary lookup,Hashmap lookup";
  output << endl;

  for(int i = 0; i < needles.size(); i++) {
    output << i << ",";
    output << needles[i] << ",";
    output << linearTimes[i] << ",";
    output << binarySearchTimes[i] << ",";
    output << dictTimes[i] << ",";
    output << hashmapTimes[i];
    output << endl;
  }

  output.close();

  return 0;
}
