/*
 * Comparison of different sorting algorithms
 *
 * Created for the ICTP Workshop on Advanced Techniques for Scientific
 * Programming and Management of Open Source Software Packages
 * 10. - 21. March, 2014 in Trieste, Italy
 *
 * Richard Berger <richard.berger@jku.at>
*/
#include <vector>
#include <limits>
#include <algorithm>
#include "sorting.h"

using namespace std;

void merge(vector<int> & v, int p, int q, int r) {
  vector<int> left(v.begin()+p, v.begin()+q+1);
  vector<int> right(v.begin()+q+1, v.begin()+r+1);
  left.push_back(numeric_limits<int>::max());
  right.push_back(numeric_limits<int>::max());

  int i = 0;
  int j = 0;

  for(int k = p; k <= r; k++) {
    if(left[i] <= right[j]) {
      v[k] = left[i];
      i++;
    } else {
      v[k] = right[j];
      j++;
    }
  }
}

void merge_sort(vector<int> & v, int p, int r) {
  if (p < r) {
    int q = (p+r)/2;
    merge_sort(v, p, q);
    merge_sort(v, q+1, r);
    merge(v, p, q, r);
  }
}

void merge_sort(vector<int> & v) {
    merge_sort(v, 0, v.size()-1);
}

int quick_sort_partition(vector<int> & v, int p, int r) {
  int pivot = v[r];
  int i = p - 1;

  for (int j = p; j < r; j++) {
    if (v[j] <= pivot) {
      i++;

      // exchange
      std::swap(v[i], v[j]);
    }
  }
  std::swap(v[i+1], v[r]);
  return i+1;
}

void quick_sort(vector<int> & v, int p, int r) {
  if (p < r) {
    int q = quick_sort_partition(v, p, r);
    quick_sort(v, p, q-1);
    quick_sort(v, q+1, r);
  }
}


void quick_sort(vector<int> & v) {
    quick_sort(v, 0, v.size()-1);
}

bool is_sorted(std::vector<int> & v) {
    for(int i = 1; i < v.size(); i++) {
      if(v[i-1] > v[i]) return false;
    }
    return true;
}
