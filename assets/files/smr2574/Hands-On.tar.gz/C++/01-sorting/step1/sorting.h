/*
 * Comparison of different sorting algorithms
 *
 * Created for the ICTP Workshop on Advanced Techniques for Scientific
 * Programming and Management of Open Source Software Packages
 * 10. - 21. March, 2014 in Trieste, Italy
 *
 * Richard Berger <richard.berger@jku.at>
*/
#ifndef SORTING_H
#define SORTING_H

#include<vector>

void insertion_sort(std::vector<int> & v);
void merge_sort(std::vector<int> & v);
void quick_sort(std::vector<int> & v);

bool is_sorted(std::vector<int> & v);

#endif // SORTING_H
