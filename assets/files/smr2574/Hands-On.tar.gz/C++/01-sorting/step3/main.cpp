/*
 * Comparison of different sorting algorithms
 *
 * Created for the ICTP Workshop on Advanced Techniques for Scientific
 * Programming and Management of Open Source Software Packages
 * 10. - 21. March, 2014 in Trieste, Italy
 *
 * Richard Berger <richard.berger@jku.at>
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <map>

#include <algorithm>
#include <chrono>
#include "sorting.h"

using namespace std;

using timer = chrono::high_resolution_clock;

int main()
{
    vector<int> lengths;
    map<string, vector<double>> timings;

    for(int i = 100; i < 1000; i += 10) {
        lengths.push_back(i);
    }

    for(int i = 1000; i < 11000; i += 100) {
        lengths.push_back(i);
    }

    /*
     * create random sequences of length N and time their sorting time
     * using different algorithms
     */
    for(const int N : lengths) {
        cout << "=========================================================" << endl;
        cout << " N = " << N << endl;
        cout << "=========================================================" << endl;

        // generate random sequence of length N
        vector<int> sequence(N, 0);

        for(int i = 0; i < N; i++) {
            sequence[i] = i;
        }

        std::random_shuffle(sequence.begin(), sequence.end());

        vector<int> a(sequence); // create a copy

        // ==========================================================================
        // std::sort
        auto start = timer::now();
        sort(a.begin(), a.end());
        auto end = timer::now();
        double delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;

        timings["std::sort"].push_back(delta);
        cout << "std::sort:" << delta << " seconds" << endl;
        cout << "Sorted: " << is_sorted(a) << endl;

        // restores initial random sequence
        copy(sequence.begin(), sequence.end(), a.begin());

        // ==========================================================================
        // Merge sort
        start = timer::now();
        merge_sort(a);
        end = timer::now();
        delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;

        timings["merge_sort"].push_back(delta);
        cout << "Merge Sort:" << delta << " seconds" << endl;
        cout << "Sorted: " << is_sorted(a) << endl;

        // restores initial random sequence
        copy(sequence.begin(), sequence.end(), a.begin());

        // ==========================================================================
        // Quick sort
        start = timer::now();
        quick_sort(a);
        end = timer::now();
        delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;

        timings["quick_sort"].push_back(delta);
        cout << "Quick Sort:" << delta << " seconds" << endl;
        cout << "Sorted: " << is_sorted(a) << endl;

        // restores initial random sequence
        copy(sequence.begin(), sequence.end(), a.begin());

        // ==========================================================================
        // Insertion sort
        start = timer::now();
        insertion_sort(a);
        end = timer::now();
        delta = chrono::duration_cast<chrono::nanoseconds>(end - start).count() / 1e9;

        timings["insertion_sort"].push_back(delta);
        cout << "Insertion Sort:" << delta << " seconds" << endl;
        cout << "Sorted: " << is_sorted(a) << endl;
    }

    // generate output as csv
    ofstream output;
    output.open("output.csv");
    output << "N,";

    for(auto kv = timings.begin(); kv != timings.end(); ++kv) {
        output << (*kv).first;
        output << ",";
    }
    output << endl;

    for(int i = 0; i < lengths.size(); i++) {
      output << lengths[i] << ",";
      for(auto kv = timings.begin(); kv != timings.end(); ++kv) {
          output << (*kv).second[i];
          output << ",";
      }
      output << endl;
    }

    output.close();

    return 0;
}

